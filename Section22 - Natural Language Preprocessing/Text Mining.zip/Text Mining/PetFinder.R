# Import libraries & datasets ----
library(tidyverse)
library(inspectdf)
library(recipes)
library(scales)
library(plotly)
library(data.table)
library(sentimentr)
library(magrittr)
library(rjson)
library(tidytext)
library(gridExtra)
library(caret)
library(caTools)
library(xgboost)
library(car)
library(Ckmeans.1d.dp)
library(highcharter)
library(yardstick)
library(glue)
library(ggsci)

petfind <- read_csv("petfind.csv")

breed <- read_csv("breed_labels.csv")
color <- read_csv("color_labels.csv")
state <- read_csv("state_labels.csv")


# Data Cleaning ----
df <- petfind %>% 
  left_join(breed,
            by = c("Breed1" = "BreedID"),
            suffix = c("", ".breed1")) %>% 
  left_join(breed,
            by = c("Breed2" = "BreedID"),
            suffix = c("", ".breed2")) %>% 
  left_join(color,
            by = c("Color1" = "ColorID"),
            suffix = c("", ".color1")) %>% 
  left_join(color,
            by = c("Color2" = "ColorID"),
            suffix = c("", ".color2")) %>% 
  left_join(color,
            by = c("Color3" = "ColorID"),
            suffix = c("", ".color3")) %>% 
  left_join(state,
            by = c("State" = "StateID")) %>% 
  mutate_at(vars(AdoptionSpeed, Type, Breed1, Breed2, Gender, Color1, Color2, Color3, 
                 MaturitySize, FurLength, Vaccinated, Dewormed, Sterilized, Health, 
                 State, VideoAmt, PhotoAmt, Type.breed1, Type.breed2), 
            as.factor) %>% 
  mutate(
    # AdoptionSpeed = dplyr::recode(AdoptionSpeed,
    #                               "0"="0 - Adopted on the same day",
    #                               "1"="1 - Adopted between 1 and 7 days",
    #                               "2"="2 - Adopted between 8 and 30 days",
    #                               "3"="3 - Adopted between 31 and 90 days",
    #                               "4"="4 - No adoption after 100 days"),
    Type = dplyr::recode(Type,
                         "1"="Dog", "2"="Cat"),
    Gender = dplyr::recode(Gender, 
                           "1"="Male", "2"="Female", "3"="Mixed")) %>% 
  mutate(has_name = ifelse(is.na(Name), 0, 1) %>% as_factor()) %>% 
  mutate(DescriptionCharacterLength = Description %>% str_length(),
         DescriptionSentencesCount = Description %>% str_count("[[:alnum:] ][.!?]"),
         DescriptionWordCount = Description %>% str_count("[[:alpha:][-]]+"),
         DescriptionCapitalsCount = Description %>% str_count("[A-Z]"),
         DescriptionLettersCount = Description %>% str_count("[A-Za-z]"),
         DescriptionPunctuationCount = Description %>% str_count("[[:punct:]]"),
         DescriptionExclamationCount = Description %>% str_count(stringr::fixed("!")),
         DescriptionQuestionCount = Description %>% str_count(stringr::fixed("?")),
         DescriptionDigitsCount = Description %>% str_count("[[:digit:]]"),
         DescriptionDistinctWordsCount = Description %>% 
           strsplit(split = ' ') %>% lapply(unique) %>% lengths())

#creating Pure Breed variable
not_pure <- c("Domestic Short Hair", "Domestic Medium Hair", "Domestic Long Hair", "Mixed Breed")
df$pure_breed <- ifelse(df$BreedName %in% not_pure, 0, 1)

df %>% glimpse()

# Missing values
df %>% 
  inspect_na() %>% 
  filter(pcnt > 0) %>% 
  show_plot()

df <- df %>% 
  select(-Type.breed2,-BreedName.breed2,-ColorName.color3,-ColorName.color2)

rec_obj <- df %>%
  select(Type.breed1,BreedName) %>% 
  recipe(~ ., data = .) %>%
  step_impute_mode(all_nominal()) %>%
  prep(stringsAsFactors = F)

df <- rec_obj %>% 
  bake(df) %>% 
  cbind(df %>% select(-Type.breed1,-BreedName))


# EDA ----

#AdoptionSpeed
df %>% 
  ggplot(aes(x = AdoptionSpeed)) +
  geom_bar(aes(fill = AdoptionSpeed)) +
  theme(axis.text.x = element_blank())

#StateName
StateName <- df %>%
  ggplot(aes(x= StateName)) +
  geom_bar(position = "fill", 
           color = "black",
           aes(fill = AdoptionSpeed)) +
  coord_flip() +
  theme(axis.title.y = element_blank()) +
  scale_y_continuous(labels = percent)
StateName %>% ggplotly()

#Type
Type <- df %>%
  ggplot(aes(x= Type, fill = AdoptionSpeed)) +
  geom_bar(#position = "fill", 
    color = "black") +
  theme(strip.text = element_text(face = "bold"), 
        axis.title.y = element_blank())
Type %>% ggplotly()

#MaturitySize
MaturitySize <- df %>%
  ggplot(aes(x = MaturitySize)) +
  geom_bar(position = "fill",
           aes(fill = AdoptionSpeed)) +
  theme(axis.title.y = element_blank(), legend.position = "top") +
  scale_y_continuous(labels = percent) +
  facet_wrap(~ Type)
MaturitySize %>% ggplotly()

#Vaccinated
Vaccinated <- df %>%
  ggplot(aes(x= Vaccinated, fill = AdoptionSpeed)) +
  geom_bar(position = "fill", color = "black") +
  scale_y_continuous(labels = percent) +
  theme(axis.title.y = element_blank(), legend.position = "top")
Vaccinated %>% ggplotly()

#Dewormed
Dewormed <- df %>%
  ggplot(aes(x= Dewormed, fill = AdoptionSpeed)) +
  geom_bar(position = "fill", color = "black") +
  scale_y_continuous(labels = percent) +
  theme(axis.title.y = element_blank(), legend.position = "top")
Dewormed %>% ggplotly()

#Sterilized
Sterilized <- df %>%
  ggplot(aes(x= Sterilized, fill = AdoptionSpeed)) +
  geom_bar(position = "fill", color = "black") +
  scale_y_continuous(labels = percent) +
  theme(axis.title.y = element_blank(), legend.position = "top")
Sterilized %>% ggplotly()

#Health
Health <- df %>%
  ggplot(aes(x= Health, fill = AdoptionSpeed)) +
  geom_bar(position = "fill", color = "black") +
  scale_y_continuous(labels = percent) +
  theme(axis.title.y = element_blank(), legend.position = "top")
Health %>% ggplotly()

#PhotoAmt
PhotoAmt <- df %>%
  ggplot(aes(x= AdoptionSpeed, y= PhotoAmt, fill = AdoptionSpeed)) +
  geom_boxplot() +
  theme(axis.text.x = element_blank())
PhotoAmt %>% ggplotly()

#Description
Description <- df %>%
  select(AdoptionSpeed, starts_with("Description"), -Description) %>%
  gather(key = "Variable", value = "value", -AdoptionSpeed) %>%
  ggplot(aes(x= log(value + 1), fill = AdoptionSpeed)) +
  geom_density(alpha = 0.3) +
  labs(title = "Description Metadata Analysis", 
       subtitle = "All metrics are counts except for 'DescriptionLexicalDensity'", 
       x = "Log transformed metric") +
  facet_wrap(~ Variable, scales = "free") 
Description %>% ggplotly()


# Text mining the Description ----

pet_words <- df %>% 
  select(PetID, AdoptionSpeed, Description) %>% 
  unnest_tokens(output = word, input = Description) 

# Listing Description Text Analysis 
words_y <- pet_words %>% 
  count(AdoptionSpeed, word, sort = T)

total_words_y <- words_y %>% 
  group_by(AdoptionSpeed) %>% 
  summarize(total = sum(n))

words_y <- words_y %>% 
  left_join(total_words_y)

# Term Frequency Inverse Document Frequency
words_y <- words_y %>%
  bind_tf_idf(word, AdoptionSpeed, n)

top_20_tbl <- words_y %>%
  arrange(desc(tf_idf)) %>%
  mutate(word = factor(word, levels = rev(unique(word)))) %>% 
  group_by(AdoptionSpeed) %>% 
  top_n(20) %>% 
  ungroup() 

top_20_tbl %>% 
  ggplot(aes(x = reorder(word, tf_idf), y = tf_idf, fill = AdoptionSpeed)) +
  geom_col(show.legend = F, color = "black") +
  scale_y_continuous(labels = comma) +
  labs(x = NULL) +
  facet_wrap(~AdoptionSpeed, ncol = 2, scales = "free") +
  coord_flip()


pet_words_total <- pet_words %>% 
  group_by(PetID) %>% 
  summarize(total_words = n())


pet_words_dcast <- pet_words %>% 
  mutate(value = 1) %>% 
  group_by(PetID,word) %>% 
  summarise(value = sum(value)) %>% 
  ungroup() %>% 
  dcast(PetID ~ word, value.var='value')

words <- pet_words_dcast %>% select(-PetID) %>% names()
words %>% as_tibble() %>% View()
words <- words %>% tail(words %>% length() - 32) 

selected_words <- words[words %in% top_20_tbl$word]
pet_words_dcast <- pet_words_dcast %>% select(PetID,all_of(selected_words))

pet_words_dcast[is.na(pet_words_dcast)] <- 0


# Sentiment Analysis ----

# Get Sentiments
df$sentiment <- df %>% 
  mutate(review_split = get_sentences(df$Description)) %$%  
  sentiment_by(review_split) 

df_sent <- df %>% 
  mutate(ave_sentiment = sentiment$ave_sentiment,
         word_count = sentiment$word_count,
         sd = sentiment$sd) %>% 
  mutate(sd = ifelse(is.na(sd),0,sd)) %>% 
  select(-sentiment,-Name,-RescuerID,-Description)


# Getting all the file path & to proceed each JSON file with for loop
filenames <- list.files("petfind_sentiment", full.names=T)

fnames <- filenames
sentiments <- c()
for(i in 1:length(fnames)){
  temp_json <- rjson::fromJSON(file = fnames[i])
  petid <- petid <- fnames[i] %>% 
    substring(19) %>% 
    strsplit(".json") %>% 
    unlist() #PetID from JSON file name
  magnitude <- temp_json[["documentSentiment"]][["magnitude"]] # Magnitude
  score <- temp_json[["documentSentiment"]][["score"]] #Sentiment Score
  language <- temp_json[["language"]] #language of the descritpion
  
  sentiments_uni <- c(petid,magnitude,score)
  sentiments <- rbind(sentiments,sentiments_uni)
}

sentiments <- sentiments %>% as.data.frame()
names(sentiments) <- c("PetID","magnitude","score")
sentiments <- sentiments %>% 
  mutate_at(vars(magnitude, score), parse_number)

# From Google Cloud (https://cloud.google.com/natural-language/docs/basics):
# Score of the sentiment ranges between -1.0 (negative) and 1.0 (positive) 
#and corresponds to the overall emotional leaning of the text.
# Magnitude indicates the overall strength of emotion (both positive and negative) 
#within the given text, between 0.0 and +inf. Unlike score, magnitude is not normalized; 
#each expression of emotion within the text (both positive and negative) contributes 
#to the text's magnitude (so longer text blocks may have greater magnitudes).


# Modeling ----

df_sent %>% glimpse()

# One hot encoding
dummies <- df_sent %>%
  select(-AdoptionSpeed,-PetID) %>%
  dummyVars(~., data = .)
matrix <- dummies %>% predict(df_sent)

df_merged <- matrix %>%
  as.data.frame() %>%
  cbind(PetID = df_sent$PetID,
        AdoptionSpeed = df_sent$AdoptionSpeed) %>% 
  left_join(sentiments, by="PetID") %>% 
  left_join(pet_words_total, by="PetID") %>%
  left_join(pet_words_dcast, by="PetID") %>% 
  select(-PetID)


# Splitting the df_merged into the train and test
set.seed(123)
split <- df_merged$AdoptionSpeed %>% sample.split(SplitRatio = 0.8)
train <- df_merged %>% subset(split == T)
test <- df_merged %>% subset(split == F)

# Fitting
set.seed(123)
model <- xgboost(data = as.matrix(train %>% select(-AdoptionSpeed)),
                 label = train$AdoptionSpeed,
                 objective = "multi:softprob",
                 eval_metric="mlogloss",
                 nrounds = 600,
                 num_class = 6,
                 eta = 0.1,
                 gamma = 0.1,
                 max_depth = 8,
                 #print_every_n = 10, 
                 maximize = T,
                 grow_policy="lossguide")

# Variable Importance
imp <- train %>% 
  select(-AdoptionSpeed) %>% 
  as.matrix() %>% 
  colnames() %>% 
  xgb.importance(model) %>% 
  arrange(desc(Frequency))

imp %>% 
  filter(Frequency > 0.01) %>% 
  xgb.ggplot.importance()

# Predicting the test set results
y_pred <- model %>% predict(as.matrix(test %>% select(-AdoptionSpeed)))


# Model evaluation ----

p <- matrix(y_pred, nrow = 6, ncol = length(y_pred)/6) %>% 
  t() %>% data.frame() %>% 
  mutate(label = test$AdoptionSpeed, max_prob = max.col(., "last")-1)

# Confusion Matrix
cm <- table(Prediction = p$max_prob, Actual = p$label)
cm 
